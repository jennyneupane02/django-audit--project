# Daily Calorie & Fitness Tracker - Django Security Audit

This project is a small Django version of a calorie and fitness tracker. It includes a homepage, calorie guide, food-entry form, and recent food-entry list.

## Security Fixes Included

- CSRF protection added to the POST form using `{% csrf_token %}`.
- User-submitted food names are rendered with Django auto-escaping using `{{ food.name }}`.
- SQL injection prevention is handled through Django's ORM instead of unsafe raw SQL string concatenation.
- `SECRET_KEY`, `DEBUG`, and `ALLOWED_HOSTS` are read from environment variables.
- Production security settings are included for HTTPS redirect and secure cookies.

## Caching

The homepage view uses Django's `@cache_page(60 * 5)` decorator. This caches the page for 5 minutes because the guide and homepage content are mostly static. The risk is that newly added food entries may not appear immediately for up to 5 minutes, which is acceptable for this small demo app.

## Scalability Design

If this application needed to handle 10x more users, I would start with vertical scaling for a small increase in traffic because it is simple to upgrade one server with more CPU and memory. If traffic continued to grow, I would move to horizontal scaling by adding multiple application servers behind a load balancer. The load balancer would distribute requests across servers using round-robin or fewest-connections routing. To avoid session problems when users move between servers, I would use database-backed sessions or a shared cache like Redis instead of storing sessions on one server. The database could also become a bottleneck, so I would use database replication with one primary database for writes and replicas for read-heavy requests. If the data became very large, I would consider partitioning or sharding the database by date or user ID.

## Running Locally

1. Install dependencies:

```bash
pip install -r requirements.txt
```

2. Set environment variables or copy `.env.example` into your environment.

3. Run migrations:

```bash
python manage.py makemigrations
python manage.py migrate
```

4. Start the server:

```bash
python manage.py runserver
```
