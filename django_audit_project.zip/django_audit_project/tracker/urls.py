from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='index'),
    path('add-food/', views.add_food, name='add_food'),
]
