function showPage(pageId) {
    document.querySelectorAll('.page').forEach(page => {
        page.style.display = 'none';
    });

    document.querySelector(`#${pageId}`).style.display = 'block';
}

document.querySelectorAll('nav button').forEach(button => {
    button.onclick = function () {
        showPage(this.dataset.page);
    };
});

document.querySelectorAll('.food-btn').forEach(button => {
    button.onclick = function () {
        const food = this.dataset.food;
        const calories = this.dataset.calories;

        document.querySelector('#food-result').textContent =
            `${food} has ${calories} calories`;
    };
});

window.onscroll = function () {
    const btn = document.querySelector('#topBtn');

    if (window.scrollY > 200) {
        btn.style.display = 'block';
    } else {
        btn.style.display = 'none';
    }
};

document.querySelector('#topBtn').onclick = function () {
    window.scrollTo({
        top: 0,
        behavior: 'smooth'
    });
};