from django.shortcuts import render, redirect
from django.views.decorators.cache import cache_page
from .models import FoodEntry


# Cache this homepage for 5 minutes (300 seconds).
# Good candidate: the intro and calorie guide are mostly static and do not change often.
# Stale data risk: users may see the older food list for up to 5 minutes after an update.
@cache_page(60 * 5)
def index(request):
    # SAFE: Django ORM uses parameterized queries internally.
    # User input is not directly joined into SQL, so SQL injection is prevented.
    foods = FoodEntry.objects.all().order_by('-created_at')[:10]

    # UNSAFE VERSION - never do this:
    # name = request.GET.get('name', '')
    # query = "SELECT * FROM tracker_foodentry WHERE name = '" + name + "'"
    # This could allow SQL injection if name contains malicious SQL.

    return render(request, 'tracker/index.html', {'foods': foods})


def add_food(request):
    if request.method == 'POST':
        name = request.POST.get('name', '').strip()
        calories = request.POST.get('calories', '0')
        if name and calories.isdigit():
            FoodEntry.objects.create(name=name, calories=int(calories))
    return redirect('index')
