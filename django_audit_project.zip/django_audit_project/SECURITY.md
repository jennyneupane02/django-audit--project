## Security Audit - Daily Calorie & Fitness Tracker

# Finding 1: Secret key exposed in settings.py
*Risk:* If a real Django `SECRET_KEY` is hardcoded in the source code, anyone who sees the repository could potentially forge session cookies or attack the application.
*Fix:* Moved `SECRET_KEY` to an environment variable using `os.environ.get()`.
*Location:* `calorie_tracker_project/settings.py`

# Finding 2: POST form missing CSRF protection
*Risk:* Without a CSRF token, an attacker could trick a user's browser into submitting a form request from another website.
*Fix:* Added `{% csrf_token %}` inside the POST form in the tracker template.
*Location:* `tracker/templates/tracker/index.html`

# Finding 3: User input could create XSS risk if rendered unsafely
*Risk:* A user could enter text such as `<script>alert('xss')</script>` into a food name field. If rendered with `|safe` or auto-escaping turned off, the script could run in another user's browser.
*Fix:* Confirmed user-supplied food names are rendered with `{{ food.name }}` so Django auto-escaping displays the input as text instead of executable code. Added a warning comment showing that `{{ food.name|safe }}` should not be used with untrusted data.
*Location:* `tracker/templates/tracker/index.html`

# Finding 4: SQL injection risk from raw SQL string concatenation
*Risk:* If user input is joined directly into a SQL query string, an attacker could submit malicious input that changes the database query.
*Fix:* Used Django's ORM with `FoodEntry.objects.all()` and `FoodEntry.objects.create()`. Django ORM uses parameterized queries internally. Added comments in `views.py` showing the unsafe version and the safe version.
*Location:* `tracker/views.py`

# Finding 5: Production settings needed stronger security
*Risk:* If `DEBUG=True` in production, error pages can expose sensitive technical details. If `ALLOWED_HOSTS` is not set, forged Host headers may be accepted. If HTTPS cookie settings are missing, cookies may be sent over insecure HTTP.
*Fix:* Set `DEBUG` from environment variables, added `ALLOWED_HOSTS`, and added HTTPS-related settings including `SECURE_SSL_REDIRECT`, `SESSION_COOKIE_SECURE`, and `CSRF_COOKIE_SECURE`.
*Location:* `calorie_tracker_project/settings.py`

# Finding 6: No caching layer
*Risk:* Without caching, repeated requests can force the server and database to do the same work again and again, reducing performance as traffic increases.
*Fix:* Added Django's `@cache_page(60 * 5)` decorator to the homepage view. The cache timeout is 5 minutes because the page is mostly static, but new food entries may appear stale for up to 5 minutes.
*Location:* `tracker/views.py`
